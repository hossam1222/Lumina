const fs = require('fs');
const fetch = require('node-fetch');

async function fetchSummary(title){
  const url = `https://en.wikipedia.org/api/rest_v1/page/mobile-sections/${encodeURIComponent(title)}`;
  const r = await fetch(url);
  if (!r.ok) return null;
  const json = await r.json();
  const text = (json.lead && json.lead.sections) ? json.lead.sections.map(s=>s.text).join('\n') : '';
  return { title: json.lead.displaytitle || title, text, url: `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}` }
}

async function main(){
  const titles = [ 'Mathematics', 'Physics', 'Computer_science' ];
  const out = [];
  for (const t of titles){
    const r = await fetchSummary(t);
    if (r) out.push(r);
    await new Promise(r=>setTimeout(r, 400));
  }
  fs.writeFileSync('wikipedia_sample.json', JSON.stringify(out, null, 2));
  console.log('done');
}

main();
