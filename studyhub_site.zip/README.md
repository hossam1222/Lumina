# StudyHub (Website)

نسخة مبسطة لموقع تعليمي يجمع مصادر مفتوحة ويعطي واجهة بحث ومفضلات ومكونات دراسة (مؤقت، قوائم مهام، ملاحظات).

## التشغيل محليًا

1. انسخ المستودع
2. أنشئ ملف `.env.local` من `.env.example` واملأ المتغيرات
3. ثبت الحزم `npm install`
4. جهّز Prisma: `npx prisma generate` ثم `npx prisma migrate dev --name init`
5. شغّل التطوير `npm run dev`
6. افتح http://localhost:3000
