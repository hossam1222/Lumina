import Link from "next/link";
import { useSession, signIn, signOut } from "next-auth/react";

export default function Navbar() {
  const { data: session } = useSession();

  return (
    <nav style={{background:'#111827', color:'#fff', padding:12, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
      <div style={{display:'flex', gap:16}}>
        <Link href="/">🏠 الرئيسية</Link>
        <Link href="/search">🔎 البحث</Link>
        <Link href="/bookmarks">⭐ المفضلات</Link>
      </div>
      <div>
        {session ? (
          <div style={{display:'flex', gap:8, alignItems:'center'}}>
            <span style={{fontSize:12}}>👤 {session.user.email}</span>
            <button onClick={()=>signOut()} style={{background:'#ef4444', color:'#fff', padding:'6px 10px', borderRadius:6}}>خروج</button>
          </div>
        ) : (
          <button onClick={()=>signIn()} style={{background:'#2563eb', color:'#fff', padding:'6px 10px', borderRadius:6}}>دخول</button>
        )}
      </div>
    </nav>
);
}
