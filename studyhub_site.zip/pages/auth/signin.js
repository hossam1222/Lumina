import { getProviders, signIn } from "next-auth/react";

export default function SignIn({ providers }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-2xl font-bold mb-6">تسجيل الدخول</h1>
      {providers && Object.values(providers).map((provider) => (
        <div key={provider.name} style={{marginBottom:10}}>
          <button
            className="bg-blue-600 text-white px-4 py-2 rounded"
            onClick={() => signIn(provider.id)}
          >
            الدخول باستخدام {provider.name}
          </button>
        </div>
      ))}
    </div>
  );
}

export async function getServerSideProps() {
  const providers = await getProviders();
  return {
    props: { providers },
  };
}
