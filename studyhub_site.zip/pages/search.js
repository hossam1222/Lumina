import { useState } from "react";
import { useSession, signIn } from "next-auth/react";

export default function SearchPage() {
  const { data: session } = useSession();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);

  const handleSearch = async () => {
    const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    setResults(data.results || []);
  };

  const handleSave = async (result) => {
    if (!session) {
      signIn(); // يوجّه المستخدم لصفحة تسجيل الدخول
      return;
    }
    const res = await fetch("/api/bookmarks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: result.title,
        link: result.link || result.url || result.page,
        snippet: result.snippet,
        source: result.source || 'unknown'
      }),
    });
    if (res.ok) {
      alert("📌 تم الحفظ في المفضلات!");
    } else {
      alert("❌ حصل خطأ أثناء الحفظ");
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🔎 البحث</h1>
      <div className="flex gap-2 mb-6">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="border p-2 rounded w-full"
          placeholder="ابحث عن أي موضوع..."
        />
        <button
          onClick={handleSearch}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          بحث
        </button>
      </div>

      <div className="space-y-4">
        {results.map((r, i) => (
          <div
            key={i}
            className="p-4 border rounded flex justify-between items-center"
          >
            <div>
              <a href={r.link || r.url || '#'} target="_blank" rel="noreferrer" className="text-lg font-semibold text-blue-700">
                {r.title}
              </a>
              <p className="text-gray-600">{r.snippet}</p>
            </div>
            <button
              onClick={() => handleSave(r)}
              className="bg-green-600 text-white px-3 py-1 rounded"
            >
              🔖 حفظ
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
