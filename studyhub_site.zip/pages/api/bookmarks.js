import { getServerSession } from "next-auth/next";
import { authOptions } from "./auth/[...nextauth]";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export default async function handler(req, res) {
  const session = await getServerSession(req, res, authOptions);
  if (!session || !session.user?.email) return res.status(401).json({ error: 'Not authenticated' });

  const userEmail = session.user.email;
  let user = await prisma.user.findUnique({ where: { email: userEmail } });
  if (!user) {
    user = await prisma.user.create({ data: { email: userEmail, name: session.user.name || undefined, image: session.user.image || undefined } });
  }

  if (req.method === 'GET') {
    const items = await prisma.bookmark.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } });
    return res.status(200).json({ items });
  }

  if (req.method === 'POST') {
    const { title, snippet, link, source } = req.body;
    if (!title || !link) return res.status(400).json({ error: 'Missing fields' });
    const bm = await prisma.bookmark.create({ data: { title, snippet: snippet || null, link, source: source || null, userId: user.id } });
    return res.status(201).json({ item: bm });
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
