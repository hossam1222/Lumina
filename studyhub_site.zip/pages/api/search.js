export default async function handler(req, res) {
  const q = (req.query.q || '').toString();
  if (!q) return res.status(200).json({ results: [] });

  const wikiUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q)}`;
  let results = [];
  try {
    const w = await fetch(wikiUrl);
    if (w.ok) {
      const wd = await w.json();
      results.push({ id: 'wiki-'+(wd.pageid||q), title: wd.title, snippet: wd.extract, link: wd.content_urls?.desktop?.page || ('https://en.wikipedia.org/wiki/'+encodeURIComponent(q)), source:'wikipedia' });
    }
  } catch(e){}

  try {
    const arxivUrl = `http://export.arxiv.org/api/query?search_query=all:${encodeURIComponent(q)}&start=0&max_results=3`;
    const a = await fetch(arxivUrl);
    if (a.ok) {
      const text = await a.text();
      results.push({ id:'arxiv1', title:'نتيجة من arXiv (قد تحتاج تحليل XML)', snippet: text.slice(0,300)+'...', link: 'https://arxiv.org' });
    }
  } catch(e){}

  return res.status(200).json({ results });
}
