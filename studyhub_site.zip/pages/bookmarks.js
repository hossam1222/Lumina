import React, {useEffect, useState} from 'react'
import { useSession } from 'next-auth/react'

export default function Bookmarks(){
  const { data: session } = useSession()
  const [b,setB]=useState([])
  useEffect(()=>{
    if (!session?.user?.email) return
    fetch('/api/bookmarks').then(r=>r.json()).then(data=> setB(data.items || []))
  },[session])
  return (
    <div style={{padding:20}}>
      <h2>مفضلاتك</h2>
      {!session ? <p>سجّل الدخول لعرض المفضلات.</p> : (
        b.length===0 ? <p>لا توجد مفضلات بعد.</p> : (
          <ul>
            {b.map(x=> (
              <li key={x.id} style={{marginBottom:10}}>
                <a href={x.link} target="_blank" rel="noreferrer">{x.title}</a>
                <div style={{fontSize:12,color:'#666'}}>{x.snippet}</div>
              </li>
            ))}
          </ul>
        )
      )}
    </div>
  )
}
