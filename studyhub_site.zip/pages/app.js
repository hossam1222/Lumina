import React, {useEffect, useState} from 'react'

export default function AppPage(){
  const [notes,setNotes] = useState('')
  useEffect(()=>{ setNotes(localStorage.getItem('study_notes_v1')||'') },[])
  useEffect(()=>{ localStorage.setItem('study_notes_v1', notes) },[notes])
  return (
    <div style={{padding:20}}>
      <h2>أدوات الدراسة</h2>
      <section>
        <h3>ملاحظات</h3>
        <textarea value={notes} onChange={e=>setNotes(e.target.value)} rows={8} style={{width:'100%'}} />
      </section>
      <section style={{marginTop:20}}>
        <h3>مؤقت Pomodoro (تجريبي)</h3>
        <p>زر البدء/إيقاف مؤقت مدمج — نسخة مجردة في الواجهة.</p>
      </section>
    </div>
  )
}
