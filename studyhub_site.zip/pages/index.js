import Link from 'next/link';
export default function Home(){ 
  return (
    <main style={{padding:30,fontFamily:'Inter,system-ui'}}>
      <h1>StudyHub — موقع التعلم</h1>
      <p>مرحبًا! هذا موقع يجمع أدوات دراسة ومحرك معرفة تجريبي.</p>
      <ul>
        <li><Link href="/app">فتح التطبيق (قائمة مهام/مؤقت/ملاحظات)</Link></li>
        <li><Link href="/search">محرك البحث في المصادر</Link></li>
        <li><Link href="/bookmarks">المفضلات</Link></li>
      </ul>
    </main>
  )
}
